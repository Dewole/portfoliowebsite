/**
 * Imports every entry from the old Decap-CMS content/*.json files (plus the
 * profile photo and CV PDF) into Payload, in both locales. Safe to re-run:
 * it looks up by slug/identifying field first and updates instead of
 * duplicating.
 *
 * Usage: npm run seed
 */
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import dotenv from 'dotenv'
import { getPayload } from 'payload'

const dirname = path.dirname(fileURLToPath(import.meta.url))

// Loaded (and payload.config imported dynamically below) *before* anything
// touches process.env — a static top-level import of payload.config would
// otherwise resolve before this line runs, evaluating buildConfig() with an
// empty DATABASE_URI/PAYLOAD_SECRET.
dotenv.config({ path: path.resolve(dirname, '../../.env') })
const legacyRoot = path.resolve(dirname, '../../legacy-content')

const readJSON = (relPath: string) =>
  JSON.parse(fs.readFileSync(path.join(legacyRoot, relPath), 'utf8'))

const readDir = (relPath: string) => {
  const dir = path.join(legacyRoot, relPath)
  if (!fs.existsSync(dir)) return []
  return fs
    .readdirSync(dir)
    .filter((f) => f.endsWith('.json'))
    .map((file) => ({ slug: file.replace(/\.json$/, ''), data: readJSON(path.join(relPath, file)) }))
}

// Pulls every `<field>_pl` sibling off an item into its own object, keyed
// by the base field name — mirrors the old lib/localize.js overlay.
const splitLocales = (item: Record<string, any>) => {
  const en: Record<string, any> = {}
  const pl: Record<string, any> = {}
  for (const key of Object.keys(item)) {
    if (key.endsWith('_pl')) {
      const base = key.slice(0, -3)
      if (item[key]) pl[base] = item[key]
    } else if (!(key in pl)) {
      en[key] = item[key]
    }
  }
  return { en, pl }
}

async function upsertByField(
  payload: Awaited<ReturnType<typeof getPayload>>,
  collection: string,
  where: Record<string, any>,
  data: Record<string, any>,
) {
  const existing = await payload.find({ collection: collection as any, where, limit: 1 })
  if (existing.docs[0]) {
    await payload.update({ collection: collection as any, id: existing.docs[0].id, data, locale: 'en' })
    return existing.docs[0].id
  }
  const created = await payload.create({ collection: collection as any, data, locale: 'en' })
  return created.id
}

async function run() {
  const { default: config } = await import('../payload.config')
  const payload = await getPayload({ config })
  console.log('▶ Seeding Brandma CMS from legacy-content/ ...')

  // ---- 1. First admin user ----
  const adminEmail = process.env.SEED_ADMIN_EMAIL || 'emmanuel@brandma.pl'
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || 'BrandmaAdmin!2026'
  const { totalDocs: userCount } = await payload.find({ collection: 'users', limit: 1 })
  if (userCount === 0) {
    await payload.create({
      collection: 'users',
      data: { email: adminEmail, password: adminPassword, name: 'Emmanuel', role: 'admin' },
    })
    console.log(`  ✓ Created admin user ${adminEmail} (password: ${adminPassword} — change it after first login)`)
  } else {
    console.log('  · Admin user(s) already exist, skipping.')
  }

  // ---- 2. Media & documents ----
  const profilePath = path.join(legacyRoot, 'images/profile.jpg')
  const cvPath = path.join(legacyRoot, 'images/cv.pdf')

  let profileMediaId: string | number | undefined
  if (fs.existsSync(profilePath)) {
    const existing = await payload.find({ collection: 'media', where: { filename: { equals: 'profile.jpg' } }, limit: 1 })
    if (existing.docs[0]) {
      profileMediaId = existing.docs[0].id
    } else {
      const buffer = fs.readFileSync(profilePath)
      const doc = await payload.create({
        collection: 'media',
        data: { alt: 'Dewole — profile photo' },
        file: { data: buffer, mimetype: 'image/jpeg', name: 'profile.jpg', size: buffer.length },
      })
      profileMediaId = doc.id
    }
    console.log('  ✓ Media: profile.jpg')
  }

  let cvDocId: string | number | undefined
  if (fs.existsSync(cvPath)) {
    const existing = await payload.find({ collection: 'documents', where: { filename: { equals: 'cv.pdf' } }, limit: 1 })
    if (existing.docs[0]) {
      cvDocId = existing.docs[0].id
    } else {
      const buffer = fs.readFileSync(cvPath)
      const doc = await payload.create({
        collection: 'documents',
        data: { label: 'CV — English' },
        file: { data: buffer, mimetype: 'application/pdf', name: 'cv.pdf', size: buffer.length },
      })
      cvDocId = doc.id
    }
    console.log('  ✓ Document: cv.pdf')
  }

  // ---- 3. Site Settings global (site.json + site.pl.json) ----
  const siteEn = readJSON('site.json')
  const sitePl = readJSON('site.pl.json')

  const { photographyImages, cvUrl, ...siteEnRest } = siteEn
  await payload.updateGlobal({
    slug: 'site-settings',
    data: { ...siteEnRest, cv: cvDocId },
    locale: 'en',
  })
  // Only push fields that are actually localized on the global — cvUrl /
  // photographyImages / identity fields are shared, not per-locale.
  const { name: _n, phone: _p, email: _e, linkedinUrl: _l, figmaUrl: _f, cvUrl: _c, ...siteplLocalized } = sitePl
  await payload.updateGlobal({ slug: 'site-settings', data: siteplLocalized, locale: 'pl' })
  console.log('  ✓ Site Settings (en + pl)')

  // ---- 4. Case Studies ----
  for (const { slug, data } of readDir('case-studies')) {
    const { en, pl } = splitLocales(data)
    const { images, ...enRest } = en
    const id = await upsertByField(payload, 'case-studies', { slug: { equals: slug } }, { slug, ...enRest })
    await payload.update({ collection: 'case-studies', id, data: pl, locale: 'pl' })
  }
  console.log('  ✓ Case Studies')

  // ---- 5. Products ----
  for (const { slug, data } of readDir('products')) {
    const { en, pl } = splitLocales(data)
    const { images, ...enRest } = en
    const id = await upsertByField(payload, 'products', { slug: { equals: slug } }, { slug, ...enRest })
    await payload.update({ collection: 'products', id, data: pl, locale: 'pl' })
  }
  console.log('  ✓ Products')

  // ---- 6. Services ----
  for (const { slug, data } of readDir('services')) {
    const { en, pl } = splitLocales(data)
    const id = await upsertByField(payload, 'services', { title: { equals: en.title } }, en)
    await payload.update({ collection: 'services', id, data: pl, locale: 'pl' })
  }
  console.log('  ✓ Services')

  // ---- 7. Testimonials ----
  for (const { data } of readDir('testimonials')) {
    const { en, pl } = splitLocales(data)
    const id = await upsertByField(payload, 'testimonials', { name: { equals: en.name }, quote: { equals: en.quote } }, en)
    await payload.update({ collection: 'testimonials', id, data: pl, locale: 'pl' })
  }
  console.log('  ✓ Testimonials')

  // ---- 8. Experience ----
  for (const { data } of readDir('experience')) {
    const { en, pl } = splitLocales(data)
    const id = await upsertByField(payload, 'experience', { company: { equals: en.company }, role: { equals: en.role } }, en)
    await payload.update({ collection: 'experience', id, data: pl, locale: 'pl' })
  }
  console.log('  ✓ Experience')

  console.log('✔ Seed complete.')
  process.exit(0)
}

run().catch((err) => {
  console.error(err)
  process.exit(1)
})
