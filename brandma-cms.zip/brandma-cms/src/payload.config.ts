import path from 'path'
import { fileURLToPath } from 'url'
import sharp from 'sharp'
import { postgresAdapter } from '@payloadcms/db-postgres'
import { lexicalEditor } from '@payloadcms/richtext-lexical'
import { buildConfig } from 'payload'

import { Users } from './collections/Users'
import { Media } from './collections/Media'
import { Documents } from './collections/Documents'
import { CaseStudies } from './collections/CaseStudies'
import { Products } from './collections/Products'
import { Services } from './collections/Services'
import { Testimonials } from './collections/Testimonials'
import { Experience } from './collections/Experience'
import { SiteSettings } from './globals/SiteSettings'

const filename = fileURLToPath(import.meta.url)
const dirname = path.dirname(filename)

export default buildConfig({
  // ---- Brand the admin panel ----
  admin: {
    user: Users.slug,
    avatar: 'default',
    theme: 'dark',
    meta: {
      title: 'Brandma CMS · Dewole Studio',
      titleSuffix: ' — Brandma CMS',
      description: 'Content admin for the Dewole portfolio site.',
      icons: [{ url: '/favicon.svg', type: 'image/svg+xml' }],
    },
    components: {
      graphics: {
        Logo: '/src/admin/components/Logo#Logo',
        Icon: '/src/admin/components/Icon#Icon',
      },
      beforeLogin: ['/src/admin/components/BeforeLogin#BeforeLogin'],
      beforeDashboard: ['/src/admin/components/BeforeDashboard#BeforeDashboard'],
    },
  },

  // ---- Bilingual content: English default, Polish overlay ----
  localization: {
    locales: [
      { label: 'English', code: 'en' },
      { label: 'Polski', code: 'pl' },
    ],
    defaultLocale: 'en',
    fallback: true,
  },

  collections: [Users, Media, Documents, CaseStudies, Products, Services, Testimonials, Experience],
  globals: [SiteSettings],

  editor: lexicalEditor(),

  secret: process.env.PAYLOAD_SECRET || '',

  typescript: {
    outputFile: path.resolve(dirname, 'payload-types.ts'),
  },

  db: postgresAdapter({
    pool: {
      connectionString: process.env.DATABASE_URI,
    },
  }),

  sharp,
})
