import type { Access, FieldAccess } from 'payload'

// Only logged-in Payload users (there's no public-facing frontend on this
// admin — every collection is edited by the studio team only).
export const isLoggedIn: Access = ({ req: { user } }) => Boolean(user)

export const isLoggedInFieldLevel: FieldAccess = ({ req: { user } }) => Boolean(user)
