import type { CollectionConfig } from 'payload'

import { isLoggedIn } from '../access/isAdmin'

export const Services: CollectionConfig = {
  slug: 'services',
  admin: {
    group: 'Content',
    useAsTitle: 'title',
    defaultColumns: ['title', 'order'],
    description: 'The services grid on the homepage.',
  },
  access: {
    read: () => true,
    create: isLoggedIn,
    update: isLoggedIn,
    delete: isLoggedIn,
  },
  defaultSort: 'order',
  fields: [
    { name: 'order', type: 'number', defaultValue: 1, admin: { position: 'sidebar' } },
    { name: 'title', type: 'text', required: true, localized: true },
    { name: 'description', type: 'textarea', localized: true },
  ],
}
