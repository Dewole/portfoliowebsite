import type { CollectionConfig } from 'payload'

import { isLoggedIn } from '../access/isAdmin'

export const Experience: CollectionConfig = {
  slug: 'experience',
  admin: {
    group: 'Content',
    useAsTitle: 'company',
    defaultColumns: ['company', 'role', 'period', 'order'],
    description: 'The work-history timeline on the About page.',
  },
  access: {
    read: () => true,
    create: isLoggedIn,
    update: isLoggedIn,
    delete: isLoggedIn,
  },
  defaultSort: 'order',
  fields: [
    {
      name: 'order',
      type: 'number',
      defaultValue: 1,
      admin: { position: 'sidebar', description: 'Most recent first.' },
    },
    { name: 'company', type: 'text', required: true, localized: true },
    { name: 'role', label: 'Role / Title', type: 'text', required: true, localized: true },
    { name: 'period', type: 'text', localized: true, admin: { description: 'e.g. "2023 — Present"' } },
    { name: 'description', type: 'textarea', localized: true },
  ],
}
