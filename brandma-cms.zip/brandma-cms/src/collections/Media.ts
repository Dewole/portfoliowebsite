import type { CollectionConfig } from 'payload'

import { isLoggedIn } from '../access/isAdmin'

// Every image in the site (profile photo, case-study/product galleries,
// photography section) lives here once, with auto-generated thumbnails so
// listing pages never have to load a full-size original.
export const Media: CollectionConfig = {
  slug: 'media',
  admin: {
    group: 'Content',
    defaultColumns: ['filename', 'alt', 'updatedAt'],
  },
  access: {
    read: () => true, // media files are served publicly to the live site
    create: isLoggedIn,
    update: isLoggedIn,
    delete: isLoggedIn,
  },
  upload: {
    staticDir: 'media',
    imageSizes: [
      { name: 'thumbnail', width: 400, height: 300, position: 'centre' },
      { name: 'card', width: 768, height: 576, position: 'centre' },
      { name: 'feature', width: 1600, height: 1000, position: 'centre' },
    ],
    adminThumbnail: 'thumbnail',
    focalPoint: true,
    mimeTypes: ['image/*'],
  },
  fields: [
    {
      name: 'alt',
      type: 'text',
      localized: true,
      admin: {
        description: 'Describe the image for accessibility and SEO (translatable).',
      },
    },
    {
      name: 'caption',
      type: 'text',
      localized: true,
      required: false,
    },
  ],
}
