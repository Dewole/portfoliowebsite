import type { CollectionConfig } from 'payload'

import { isLoggedIn } from '../access/isAdmin'
import { formatSlug } from '../hooks/formatSlug'

export const Products: CollectionConfig = {
  slug: 'products',
  admin: {
    group: 'Content',
    useAsTitle: 'name',
    defaultColumns: ['name', 'status', 'category', 'order'],
    description: 'Shipped products shown on /products/ and their detail pages.',
  },
  access: {
    read: () => true,
    create: isLoggedIn,
    update: isLoggedIn,
    delete: isLoggedIn,
  },
  defaultSort: 'order',
  fields: [
    {
      name: 'order',
      type: 'number',
      defaultValue: 1,
      admin: { position: 'sidebar' },
    },
    {
      name: 'slug',
      type: 'text',
      unique: true,
      index: true,
      admin: { position: 'sidebar', description: 'URL path — /products/<slug>/. Auto-filled from the name.' },
      hooks: { beforeValidate: [formatSlug('name')] },
    },
    {
      name: 'status',
      type: 'select',
      defaultValue: 'live',
      admin: { position: 'sidebar' },
      options: [
        { label: 'Live', value: 'live' },
        { label: 'Coming soon', value: 'coming-soon' },
      ],
    },
    {
      name: 'thumbClass',
      label: 'Thumbnail tint',
      type: 'select',
      defaultValue: '',
      admin: { position: 'sidebar' },
      options: [
        { label: 'Amber (default)', value: '' },
        { label: 'Teal', value: 'b' },
        { label: 'Violet', value: 'c' },
      ],
    },
    {
      name: 'link',
      type: 'text',
      defaultValue: '#',
      admin: { position: 'sidebar', description: 'Live product URL, or leave as # if not public yet.' },
    },
    { name: 'name', type: 'text', required: true, localized: true },
    { name: 'description', type: 'textarea', localized: true },
    {
      name: 'category',
      type: 'text',
      localized: true,
      admin: { description: 'Feeds the filter pills on /products/.' },
    },
    { name: 'problem', label: 'The problem', type: 'textarea', localized: true },
    { name: 'approach', label: 'The approach', type: 'textarea', localized: true },
    { name: 'outcome', label: 'The outcome', type: 'textarea', localized: true },
    {
      name: 'gallery',
      type: 'upload',
      relationTo: 'media',
      hasMany: true,
      admin: {
        description:
          "Extra photos for this product's detail page. Leave empty and the page falls back to the gradient placeholder.",
      },
    },
  ],
}
