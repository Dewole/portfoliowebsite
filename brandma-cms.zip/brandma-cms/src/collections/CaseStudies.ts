import type { CollectionConfig } from 'payload'

import { isLoggedIn } from '../access/isAdmin'
import { formatSlug } from '../hooks/formatSlug'

export const CaseStudies: CollectionConfig = {
  slug: 'case-studies',
  labels: { singular: 'Case Study', plural: 'Case Studies' },
  admin: {
    group: 'Content',
    useAsTitle: 'title',
    defaultColumns: ['title', 'category', 'order', 'updatedAt'],
    description: "Portfolio work shown on /portfolio/ and its detail pages.",
  },
  access: {
    read: () => true,
    create: isLoggedIn,
    update: isLoggedIn,
    delete: isLoggedIn,
  },
  defaultSort: 'order',
  fields: [
    {
      name: 'order',
      type: 'number',
      defaultValue: 1,
      admin: { description: 'Display order on the Portfolio listing (lower = earlier).', position: 'sidebar' },
    },
    {
      name: 'slug',
      type: 'text',
      unique: true,
      index: true,
      admin: { position: 'sidebar', description: 'URL path — /portfolio/<slug>/. Auto-filled from the title.' },
      hooks: { beforeValidate: [formatSlug('title')] },
    },
    {
      name: 'thumbClass',
      label: 'Thumbnail tint',
      type: 'select',
      defaultValue: '',
      admin: { position: 'sidebar' },
      options: [
        { label: 'Amber (default)', value: '' },
        { label: 'Teal', value: 'b' },
        { label: 'Violet', value: 'c' },
      ],
    },
    {
      name: 'link',
      type: 'text',
      defaultValue: '#',
      admin: { position: 'sidebar' },
    },
    {
      name: 'title',
      type: 'text',
      required: true,
      localized: true,
    },
    {
      type: 'row',
      fields: [
        { name: 'tag', type: 'text', localized: true, admin: { description: 'e.g. B2B · Health', width: '50%' } },
        {
          name: 'category',
          type: 'text',
          localized: true,
          admin: { description: 'Feeds the filter pills — any value works, new ones appear automatically.', width: '50%' },
        },
      ],
    },
    {
      name: 'date',
      type: 'text',
      admin: { description: 'e.g. "Month 20XX" — not translated.' },
    },
    {
      type: 'row',
      fields: [
        { name: 'client', type: 'text', localized: true, admin: { width: '50%' } },
        { name: 'role', type: 'text', localized: true, admin: { description: 'Your role on this project', width: '50%' } },
      ],
    },
    { name: 'overview', type: 'textarea', localized: true, label: 'Project overview' },
    { name: 'objective', type: 'textarea', localized: true },
    { name: 'approach', type: 'textarea', localized: true },
    { name: 'outcome', type: 'textarea', localized: true },
    {
      name: 'gallery',
      label: 'Gallery',
      type: 'upload',
      relationTo: 'media',
      hasMany: true,
      admin: {
        description:
          "Extra photos for this case study's detail page. Leave empty and the page falls back to the gradient placeholder.",
      },
    },
  ],
}
