import type { CollectionConfig } from 'payload'

import { isLoggedIn } from '../access/isAdmin'

export const Testimonials: CollectionConfig = {
  slug: 'testimonials',
  admin: {
    group: 'Content',
    useAsTitle: 'name',
    defaultColumns: ['name', 'rating', 'order'],
    description: 'Client quotes shown in the testimonial carousel.',
  },
  access: {
    read: () => true,
    create: isLoggedIn,
    update: isLoggedIn,
    delete: isLoggedIn,
  },
  defaultSort: 'order',
  fields: [
    { name: 'order', type: 'number', defaultValue: 1, admin: { position: 'sidebar' } },
    {
      name: 'rating',
      type: 'number',
      min: 1,
      max: 5,
      defaultValue: 5,
      admin: { position: 'sidebar' },
    },
    { name: 'quote', type: 'textarea', required: true, localized: true },
    { name: 'name', label: 'Client name', type: 'text', required: true, localized: true },
  ],
}
