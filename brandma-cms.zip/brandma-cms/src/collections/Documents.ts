import type { CollectionConfig } from 'payload'

import { isLoggedIn } from '../access/isAdmin'

// Non-image downloadables (currently just the CV/resume PDF linked from the
// homepage CTA). Kept separate from Media so that collection can stay
// image-only and every entry there reliably has thumbnails.
export const Documents: CollectionConfig = {
  slug: 'documents',
  admin: {
    group: 'Content',
    defaultColumns: ['filename', 'updatedAt'],
  },
  access: {
    read: () => true,
    create: isLoggedIn,
    update: isLoggedIn,
    delete: isLoggedIn,
  },
  upload: {
    staticDir: 'documents',
    mimeTypes: ['application/pdf'],
  },
  fields: [
    {
      name: 'label',
      type: 'text',
      localized: true,
      admin: { description: 'Internal label, e.g. "CV — English"' },
    },
  ],
}
