import { redirect } from 'next/navigation'

// This project is an admin-only CMS — the root path just sends visitors
// straight into the studio.
export default function RootRedirect() {
  redirect('/admin')
}
