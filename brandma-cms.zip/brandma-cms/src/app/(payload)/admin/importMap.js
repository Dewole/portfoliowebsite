import { Icon as Icon_3f882480d09a96f54b4225e4fde0ddb2 } from '../../../../src/admin/components/Icon'
import { Logo as Logo_173c918b12b4399111aa7f3374c84d44 } from '../../../../src/admin/components/Logo'
import { BeforeDashboard as BeforeDashboard_4c879229d2ee4cc27ed370d765029bd3 } from '../../../../src/admin/components/BeforeDashboard'
import { BeforeLogin as BeforeLogin_202d8da76015b94db9714c71cd0908f1 } from '../../../../src/admin/components/BeforeLogin'
import { CollectionCards as CollectionCards_f9c02e79a4aed9a3924487c0cd4cafb1 } from '@payloadcms/next/rsc'

/** @type import('payload').ImportMap */
export const importMap = {
  "/src/admin/components/Icon#Icon": Icon_3f882480d09a96f54b4225e4fde0ddb2,
  "/src/admin/components/Logo#Logo": Logo_173c918b12b4399111aa7f3374c84d44,
  "/src/admin/components/BeforeDashboard#BeforeDashboard": BeforeDashboard_4c879229d2ee4cc27ed370d765029bd3,
  "/src/admin/components/BeforeLogin#BeforeLogin": BeforeLogin_202d8da76015b94db9714c71cd0908f1,
  "@payloadcms/next/rsc#CollectionCards": CollectionCards_f9c02e79a4aed9a3924487c0cd4cafb1
}
