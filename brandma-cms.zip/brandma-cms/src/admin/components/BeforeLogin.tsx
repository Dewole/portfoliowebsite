import React from 'react'

export const BeforeLogin: React.FC = () => (
  <div
    style={{
      marginBottom: 24,
      padding: '14px 16px',
      borderRadius: 10,
      background: 'linear-gradient(135deg, rgba(191,224,255,0.12), rgba(167,139,250,0.10))',
      border: '1px solid rgba(191,224,255,0.18)',
      fontSize: 13.5,
      lineHeight: 1.5,
      color: 'var(--theme-text, #e6e9ee)',
    }}
  >
    Welcome back — sign in to edit the Dewole site: case studies, products, testimonials, and
    every piece of copy, in English and Polish.
  </div>
)

export default BeforeLogin
