import React from 'react'

const cards = [
  {
    title: 'Site Settings',
    desc: 'Hero copy, bio, contact info, footer — the global text shared across every page.',
  },
  {
    title: 'Case Studies & Products',
    desc: 'Your portfolio and shipped products, each with a gallery and full EN/PL copy.',
  },
  {
    title: 'Switch languages',
    desc: 'Use the locale switcher in the top bar — EN / PL — to edit each translation.',
  },
]

export const BeforeDashboard: React.FC = () => (
  <div style={{ marginBottom: 8 }}>
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
        gap: 12,
        marginBottom: 8,
      }}
    >
      {cards.map((c) => (
        <div
          key={c.title}
          style={{
            padding: '16px 18px',
            borderRadius: 12,
            background:
              'linear-gradient(160deg, var(--theme-elevation-50, #13151b), var(--theme-elevation-100, #1a1d24))',
            border: '1px solid var(--theme-elevation-150, rgba(255,255,255,0.06))',
          }}
        >
          <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 6 }}>{c.title}</div>
          <div style={{ fontSize: 13, lineHeight: 1.5, opacity: 0.75 }}>{c.desc}</div>
        </div>
      ))}
    </div>
  </div>
)

export default BeforeDashboard
