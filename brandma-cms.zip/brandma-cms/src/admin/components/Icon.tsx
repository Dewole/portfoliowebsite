import React from 'react'

// Small mark used in the collapsed nav rail and as a fallback app icon.
export const Icon: React.FC = () => (
  <svg width="24" height="24" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="bm-icon-grad" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#bfe0ff" />
        <stop offset="55%" stopColor="#7dd3fc" />
        <stop offset="100%" stopColor="#a78bfa" />
      </linearGradient>
    </defs>
    <rect width="40" height="40" rx="11" fill="#0a0b10" />
    <path
      d="M12 28V12h7.2c3.4 0 5.6 1.7 5.6 4.4 0 1.9-1.1 3.2-2.7 3.7 1.9.5 3.1 1.9 3.1 4 0 3-2.3 4.9-6 4.9H12Zm4-9.6h2.7c1.5 0 2.4-.7 2.4-1.9 0-1.2-.9-1.8-2.4-1.8H16v3.7Zm0 6.2h3.1c1.7 0 2.7-.8 2.7-2.1 0-1.3-1-2-2.7-2H16v4.1Z"
      fill="url(#bm-icon-grad)"
    />
  </svg>
)

export default Icon
