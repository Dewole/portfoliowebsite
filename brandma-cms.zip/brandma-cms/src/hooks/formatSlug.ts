import type { FieldHook } from 'payload'

// Mirrors the old system's behavior (filename became the slug): editors
// don't have to think about slugs at all — one is derived from the English
// title/name the first time an entry is saved, and stays stable afterward
// even if the title later changes.
export const slugify = (value: string): string =>
  value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')

export const formatSlug = (fallbackFieldName: string): FieldHook =>
  ({ value, originalDoc, data }) => {
    if (typeof value === 'string' && value.length > 0) return slugify(value)

    if (originalDoc?.slug) return originalDoc.slug

    const fallback = data?.[fallbackFieldName]
    if (typeof fallback === 'string' && fallback.length > 0) return slugify(fallback)

    return value
  }
