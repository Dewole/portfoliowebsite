import type { GlobalConfig } from 'payload'

import { isLoggedIn } from '../access/isAdmin'

const t = (name: string, opts: Record<string, unknown> = {}) => ({
  name,
  type: 'text' as const,
  localized: true,
  ...opts,
})
const ta = (name: string, opts: Record<string, unknown> = {}) => ({
  name,
  type: 'textarea' as const,
  localized: true,
  ...opts,
})

// One global, in Payload's own bilingual fields, replacing the old
// site.json + site.pl.json pair. Every field below existed as either a
// plain field or a `<field>_pl` sibling in the previous Decap setup —
// switching the locale selector at the top of the admin now edits the
// same field's English or Polish value directly.
export const SiteSettings: GlobalConfig = {
  slug: 'site-settings',
  label: 'Site Settings',
  admin: {
    group: 'Content',
    description: 'Global copy: hero, bio, contact info, footer — shared across every page.',
  },
  access: {
    read: () => true,
    update: isLoggedIn,
  },
  fields: [
    {
      type: 'tabs',
      tabs: [
        {
          label: 'Identity & Contact',
          fields: [
            { name: 'name', type: 'text', required: true, admin: { description: 'Not localized — a proper name.' } },
            t('role', { label: 'Role / Title' }),
            { name: 'phone', type: 'text' },
            { name: 'email', type: 'email' },
            { name: 'linkedinUrl', label: 'LinkedIn URL', type: 'text' },
            { name: 'figmaUrl', label: 'Figma URL', type: 'text' },
            ta('metaDescription', { label: 'Meta description (SEO)' }),
            t('availabilityStatus', { label: 'Availability status (About/Contact pill)' }),
            {
              name: 'cv',
              label: 'CV / Resume (PDF)',
              type: 'upload',
              relationTo: 'documents',
              admin: { description: 'Shown as a download link under the homepage CTA card.' },
            },
          ],
        },
        {
          label: 'Homepage — Hero',
          fields: [
            t('heroEyebrow', { label: 'Eyebrow label' }),
            t('heroTitle', { label: 'Title' }),
            t('heroSubtitle', { label: 'Subtitle (script line)' }),
            t('heroHandwriteText', { label: 'Handwritten line' }),
            t('updatedLabel', { label: 'Entity overview — updated label' }),
          ],
        },
        {
          label: 'Homepage — About/Bio',
          fields: [
            ta('bioParagraph', { label: 'Bio paragraph ("Who is..." section)' }),
            ta('specialties', { label: 'Specialties line' }),
            ta('proof', { label: 'Proof line' }),
            ta('industries', { label: 'Industries line' }),
            ta('aboutHeading', { label: 'About — heading' }),
            ta('aboutParagraph', { label: 'About — paragraph' }),
          ],
        },
        {
          label: 'Homepage — How I Work',
          fields: [
            t('howIWorkHeading', { label: 'Heading' }),
            ta('howIWorkIntro', { label: 'Intro' }),
            t('howIWorkStep1Title', { label: 'Step 1 — title' }),
            ta('howIWorkStep1Desc', { label: 'Step 1 — description' }),
            t('howIWorkStep2Title', { label: 'Step 2 — title' }),
            ta('howIWorkStep2Desc', { label: 'Step 2 — description' }),
            t('howIWorkStep3Title', { label: 'Step 3 — title' }),
            ta('howIWorkStep3Desc', { label: 'Step 3 — description' }),
          ],
        },
        {
          label: 'Homepage — Services & Stats',
          fields: [
            t('servicesHeading', { label: 'Services — heading' }),
            ta('servicesSubheading', { label: 'Services — subheading' }),
            t('statsHeading', { label: 'Stats — heading' }),
            ta('statsParagraph', { label: 'Stats — paragraph' }),
            t('statNumber', { label: 'Stats — big number' }),
            ta('statCaption', { label: 'Stats — caption' }),
          ],
        },
        {
          label: 'Homepage — Quote & CTA',
          fields: [
            t('bigQuoteLead', { label: 'Big quote — lead (bright text)' }),
            t('bigQuoteFade', { label: 'Big quote — fade (muted text)' }),
            ta('bigQuoteParagraph', { label: 'Big quote — paragraph' }),
            t('ctaCardHeading', { label: 'CTA card — heading' }),
            ta('ctaCardParagraph', { label: 'CTA card — paragraph' }),
            t('finalCtaHeading', { label: 'Final CTA — heading' }),
            t('finalCtaSubheading', { label: 'Final CTA — subheading' }),
          ],
        },
        {
          label: 'Homepage — Photography',
          fields: [
            t('photographyKicker', { label: 'Kicker' }),
            t('photographyHeading', { label: 'Heading' }),
            ta('photographyIntro', { label: 'Paragraph' }),
            t('photographyCtaLabel', { label: '"View more" link label (blank to hide)', required: false }),
            t('photographyCtaUrl', { label: '"View more" link URL', required: false }),
            {
              name: 'photographyImages',
              label: 'Gallery images (shared across languages)',
              type: 'upload',
              relationTo: 'media',
              hasMany: true,
            },
          ],
        },
        {
          label: 'About Page',
          fields: [
            ta('aboutBioLong', { label: 'Long bio' }),
            t('experienceHeading', { label: 'Experience section — heading' }),
            ta('experienceIntro', { label: 'Experience section — intro', required: false }),
            t('aboutCtaHeading', { label: 'Closing CTA — heading' }),
            ta('aboutCtaParagraph', { label: 'Closing CTA — paragraph' }),
            t('aboutCtaButtonLabel', { label: 'Closing CTA — button label' }),
          ],
        },
        {
          label: 'Contact Page & Footer',
          fields: [
            t('contactHeading', { label: 'Contact — heading' }),
            ta('contactIntro', { label: 'Contact — intro' }),
            { name: 'copyrightYear', type: 'text' },
            t('footerNote', { label: 'Footer note' }),
          ],
        },
      ],
    },
  ],
}
