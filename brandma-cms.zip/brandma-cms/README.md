# Brandma CMS

A [Payload CMS](https://payloadcms.com) admin for the Dewole portfolio site — replaces the
old Decap CMS (`/admin/` in `cms-portfolio_7`) with a real, self-hosted admin: bilingual
(English/Polish) content, image uploads with automatic thumbnails, and a custom dark theme
that matches the site's own palette.

Every collection and every piece of copy from the old `content/*.json` files has already
been migrated in — see **Importing your content** below to load it into your own database.

## What's in here

| Collection / Global | Old source | Notes |
|---|---|---|
| **Site Settings** (global) | `content/site.json` + `site.pl.json` | Hero, bio, contact, footer — every field localized |
| **Case Studies** | `content/case-studies/*.json` | Portfolio entries, with a gallery upload field |
| **Products** | `content/products/*.json` | Shipped products, with status + gallery |
| **Services** | `content/services/*.json` | Homepage services grid |
| **Testimonials** | `content/testimonials/*.json` | Client quotes |
| **Experience** | `content/experience/*.json` | About-page work timeline |
| **Media** | `src/assets/images/*` | Images only — auto-generates `thumbnail` / `card` / `feature` sizes |
| **Documents** | `src/assets/cv.pdf` | Non-image downloads (the CV/résumé PDF) |
| **Users** | — | Admin accounts (email/password login) |

Every text field that had a `<field>_pl` sibling in the old JSON is now a single
**localized field** — switch the "Locale" dropdown at the top of the admin (English ⇄
Polski) to edit either language, with English as the fallback if a Polish value is blank
(same behavior as the old `lib/localize.js`, just built into the CMS).

## 1. Prerequisites

- Node.js 18.20+ (20 or 22 recommended)
- A Postgres database. Two free, zero-install options:
  - [Neon](https://neon.tech) — free tier, gives you a connection string in ~1 minute
  - [Supabase](https://supabase.com) — same idea, also free
  - Or point it at any Postgres you already run (local, Railway, RDS, etc.)

## 2. Install & configure

```bash
npm install
cp .env.example .env
```

Edit `.env`:

```bash
DATABASE_URI=postgres://user:password@host:5432/dbname   # from Neon/Supabase/your own Postgres
PAYLOAD_SECRET=$(openssl rand -base64 32)                 # any long random string
```

## 3. Import your content

This creates the database tables (first run only), imports everything from
`legacy-content/` (a copy of the old `content/*.json` files, plus the profile photo and
CV PDF) in both languages, and creates your first admin login:

```bash
npm run dev        # starts the app once — Ctrl+C after it says "Ready" / pushes the schema
npm run seed        # imports all content — safe to re-run, it updates instead of duplicating
```

The seed script prints the admin email/password it created
(`emmanuel@brandma.pl` / `BrandmaAdmin!2026` by default — override with the
`SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` env vars before running it if you'd rather set
your own from the start). **Log in and change that password immediately** — see
**Security** below.

## 4. Run it

```bash
npm run dev
```

Open **http://localhost:3000/admin** and log in.

For production, `npm run build && npm run start`, or deploy to any Node host (Render,
Railway, Fly.io, a VPS...). Vercel works too, but its serverless functions need a
serverless-friendly Postgres driver (`@payloadcms/db-vercel-postgres`) instead of
`@payloadcms/db-postgres` — swap that one package if you deploy there.

## 5. Deploy to Render (get a real public URL)

This repo includes `render.yaml` — a Render "Blueprint" that provisions the Postgres
database and the web service together, with `DATABASE_URI` and `PAYLOAD_SECRET` wired up
automatically. You never touch either value by hand.

**a. Push this project to a GitHub repo.** Render deploys from git, so it needs to live
there first:

```bash
# create an empty repo at github.com/new first (no README/license — just the empty repo),
# then inside the unzipped project folder:
git init
git add -A
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

**b. Connect it on Render.**

1. Sign up / log in at [render.com](https://render.com).
2. **New +** → **Blueprint**.
3. Authorize Render's GitHub app for that one repo (Render will prompt you) and select it.
4. Render reads `render.yaml` and shows you the database + web service it's about to
   create. Click **Apply**.
5. First deploy takes a few minutes (installing dependencies + building). When it's
   done, Render gives you a URL like `https://brandma-cms.onrender.com` — that's your
   live admin at `/admin`.

**c. Seed the production database once.** The Blueprint creates an *empty* database —
run the same import against it that you ran locally. In the Render dashboard, open the
`brandma-cms-db` database → **Connect** → copy the **External Connection String**, then
from your own machine:

```bash
DATABASE_URI="<external connection string from Render>" npm run seed
```

That's a one-time step; after it, `/admin` on your Render URL has all the same content.

**Two things to know about the free tier:**

- The free web service **spins down after 15 minutes idle** and takes ~30–50 seconds to
  wake back up on the next request — normal, not broken.
- The free web service has **no persistent disk**, so files uploaded through Media/
  Documents (the profile photo, CV, and anything you upload later) are lost whenever the
  container restarts or you redeploy. Fine for clicking around and confirming everything
  works; for real day-to-day use you'd want either a Render paid plan with a **Disk**
  attached, or to swap local storage for an S3-compatible bucket (Cloudflare R2 has a
  free tier) via `@payloadcms/storage-s3` — ask if you'd like that wired in.

## Branding

- Dark-only admin theme (`admin.theme: 'dark'` in `src/payload.config.ts`), re-skinned in
  `src/app/(payload)/custom.scss` using the exact `--dark` / `--dark-card` / `--accent`
  colors from the live site's `src/assets/style.css`, plus its Instrument Sans body font.
- Custom logo/icon (`src/admin/components/Logo.tsx`, `Icon.tsx`) — a small wordmark, no
  external image dependency.
- A welcome note on the login screen and three orientation cards on the dashboard
  (`src/admin/components/BeforeLogin.tsx`, `BeforeDashboard.tsx`).
- To swap the palette, colors, or copy, those five files are the only places to look —
  everything else is Payload's default UI reading from the CSS variables `custom.scss`
  overrides.

## Security

- Change the seeded admin password on first login (**Account** in the top-right menu).
- `.env` is git-ignored — never commit real database credentials or `PAYLOAD_SECRET`.
- The `media` and `documents` collections are readable by anyone (so the live site can
  display images/CV without logging in), but writing to any collection requires being
  logged in.

## Next step: connecting the live site

This admin is intentionally standalone for now — the Eleventy site in `cms-portfolio_7`
still reads from its local `content/*.json` files and its own Decap CMS at `/admin/`.
Nothing about the live site changes until you wire it up, which keeps this rollout safe to
test on its own first.

When you're ready to switch the live site over to pull from here instead:

1. Deploy this project somewhere with a stable URL (Render/Railway/Fly.io/VPS + your
   Postgres).
2. In `cms-portfolio_7`, replace `lib/loadCollection.js`'s filesystem read with a fetch
   against this admin's REST API, e.g. `GET https://your-cms-url/api/case-studies?locale=en&depth=1`
   (add `&locale=pl` for the Polish build pass) — Eleventy's `_data/*.js` files are just
   functions, so they can `await fetch(...)` at build time instead of reading `content/`.
3. Do the same for `content/site.json`/`site.pl.json` → `GET /api/globals/site-settings?locale=en|pl`.
4. Point image `src`s at the Media URLs Payload returns (e.g. `doc.gallery[0].sizes.card.url`)
   instead of the old static `/assets/uploads/...` paths.
5. Once the Eleventy build is pulling cleanly from both locales, retire `/admin/` (Decap)
   and the `content/` JSON files — this admin becomes the single source of truth.

This is a deliberately separate pass so the live site's build never breaks while you're
still setting the CMS up.

## Local development notes

- `npm run seed` reads from `legacy-content/` (copied from the old site's `content/`
  folder, plus `src/assets/profile.jpg` and `src/assets/cv.pdf`) — it's part of this repo
  so re-seeding a fresh database always reproduces the same starting content.
- `npm run generate:types` regenerates `src/payload-types.ts` after changing any
  collection/global — re-run it whenever you edit files under `src/collections` or
  `src/globals`.
- `npm run generate:importmap` regenerates `src/app/(payload)/admin/importMap.js` — only
  needed if you add/rename custom admin components; the dev server does this
  automatically on its own.
